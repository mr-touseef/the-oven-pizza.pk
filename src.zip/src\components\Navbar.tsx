"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import CartIcon from "./CartIcon";

const LINKS = [
  { href: "/#pizzas", label: "Pizzas" },
  { href: "/#burgers", label: "Burgers" },
  { href: "/#shawarma", label: "Shawarma" },
  { href: "/#drinks", label: "Drinks" },
  { href: "/#deals", label: "Deals" },
  { href: "/#branches", label: "Branches" },
  { href: "/#contact", label: "Contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-colors duration-300 ${
        scrolled ? "bg-oven-char/90 backdrop-blur-md shadow-card" : "bg-transparent"
      }`}
    >
      <nav
        aria-label="Primary"
        className="container-page flex h-16 items-center justify-between gap-3 sm:h-20"
      >
        <Link
          href="/#top"
          className="flex shrink-0 items-center gap-2 font-display text-xl font-semibold tracking-tight text-oven-cream sm:text-2xl"
        >
          <span
            className="flex h-9 w-9 items-center justify-center rounded-full bg-flame-gradient text-base font-bold text-oven-charcoal sm:h-10 sm:w-10"
            aria-hidden="true"
          >
            O
          </span>
          <span className="hidden sm:inline">
            The Oven <span className="text-oven-flame-light">Pizza</span>
          </span>
        </Link>

        <div className="scrollbar-none flex-1 overflow-x-auto">
          <ul className="flex items-center gap-5 whitespace-nowrap lg:justify-center lg:gap-7">
            {LINKS.map((link) => (
              <li key={link.href}>
                <a href={link.href} className="text-sm font-medium text-oven-cream/80 transition-colors hover:text-oven-flame-light">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex shrink-0 items-center gap-3">
          <CartIcon />
          <a href={`tel:${(process.env.NEXT_PUBLIC_RESTAURANT_PHONE_PRIMARY || "0304-1114303").replace(/-/g, "")}`} className="hidden rounded-full bg-flame-gradient px-5 py-2.5 text-sm font-semibold text-oven-charcoal shadow-ember transition-transform hover:scale-[1.03] focus-visible:scale-[1.03] sm:inline-block">
            Call to Order
          </a>
        </div>
      </nav>
    </header>
  );
}